package kemalkeskin.keskinRental;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KeskinRentalApplicationTests {

	@Test
	void contextLoads() {
	}

}
